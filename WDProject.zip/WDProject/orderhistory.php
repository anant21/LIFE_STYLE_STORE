<?php
require("inc/com.php");
if (!isset($_SESSION['email'])) {
    header('location: login.php');
}
?>
<!DOCTYPE html>
<html>
<head>

<title>Your Orders | Lifestyle Store</title>

<!--The width=device-width part sets the width of the page to follow the screen-width of the device (which will vary depending on the device).
The initial-scale=1 part sets the initial zoom level when the page is first loaded by the browser.-->
<meta name="viewport" content="width=device-width, initial-scale=1" />


<!-- Latest compiled and minified CSS -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- jQuery library -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled and minified JavaScript -->

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link  href="style.css" type="text/css" rel="stylesheet">
<link rel="icon" type="image/icon" href="img/head-logo1.png"> <!--For The Logo in the title-->



</head>
<body style=" background: url('img/intro-bg_1.jpg') no-repeat center; background-size: cover;">

    <?php include 'inc/head.php'; ?>
            <br><br><br><br><br>
        <div class="container-fluid" id="content">
            
                <div class="col-md-8 col-md-offset-2 col-xs-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3><b><span class="glyphicon glyphicon-list-alt"></span> Your Orders</b></h3>
                        </div>
                    
                    <div class="panel-body">
                        <br>
                    <table class="table table-responsive table-hover">
    
                        <!--show table only if there are items added in the cart-->
                        <?php
                        $id=0;
                        $user_id = $_SESSION['user_id'];
                        $query = "SELECT items.price AS Price, items.pid, items.name AS Name, timestamp FROM users_items JOIN items ON users_items.item_id = items.pid WHERE users_items.user_id='$user_id' 
                        and status='Confirmed' order by timestamp desc";
                        $result = mysqli_query($con, $query)or die(mysqli_error($con));
                        if (mysqli_num_rows($result) >= 1) {
                            ?>
                            <thead>
                                <tr>
                                    <th>Item Number</th>
                                    <th>Item Name</th>
                                    <th>Price</th>
                                    <th>Order Date & Time<th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //it checks if above query have fetched any detail from the database
                                //if yes then all the orders done by user is displayed in descending order of the date - time
                                //latest order is shown first
                                //if no then empty cart message is displayed
                                while ($row = mysqli_fetch_array($result)) {

                                    $id .= $row["pid"] . ", ";
                                    echo "<tr><td>" . "#" . $row["pid"] . "</td><td><b>" . $row["Name"] . "</b></td><td>Rs " . $row["Price"] . "</td><td>". $row["timestamp"] ."</td></tr>";
                                }
                                ?>
                            </tbody>
                            <?php
                        } else {
                           echo "<div class='col-md-12 col-xs-12' >";
                           echo "<center>No order has been placed!</center>";
                        }
                        ?>
                        
                    </table>
           <?php    
                    //If the order history is not present then the red with "shop now" on it is displayed to the user
                    if(mysqli_num_rows($result) == 0) {
                    echo "</div><div class='panel-footer'><a href='products.php' class='btn btn-danger'>Shop Now</a></div></div>";

                }   
                    //If order history is present then the blue button with "shop more" on it is displayed
                else{ ?>    </div> <!--panel-body ends here-->
                            <div class='panel-footer'><a href='products.php' class='btn btn-primary'>Shop More</a></div>
                            </div> <!--panel-primary ends here-->
            <?php } ?>
                </div>   <!--class-col ends here-->
            
        </div>  <!--container ends here-->
        <br><br><br><br><br><br><br><br><br><br><br><br><br>
        <?php include 'inc/foot.php'; ?>
    </body>
</html>