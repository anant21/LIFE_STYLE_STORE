<footer> 
<div class="container"> 
<center > 
    <h5>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 8448444853</h5> 
</center> 
</div> 
</footer>